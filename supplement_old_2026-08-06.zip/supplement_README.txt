Supplementary material for “Spectral Fibers for Pure-Relative Matrix Learning
and Hessian Correction.”

Files
-----
historical_curvature_study.py
    Runs the MobileNetV3/CIFAR-10 last-layer Hessian experiment. It downloads
    CIFAR-10 and the default torchvision MobileNetV3-Small checkpoint when they
    are not cached. Reference and target curvature sets are disjoint, and the
    historical correction family is frozen before target HVP queries.

deep_curvature_study.py, kfac_residual_study.py
    Shared feature extraction, implicit Hessian, K-FAC, EK-FAC, regression,
    Lanczos, and PCG routines used by historical_curvature_study.py.

historical_full_modes8*_results.json
    Raw main, high-budget, robustness, EK-FAC, and 150-step Lanczos outputs.

make_deep_figure.py
    Rebuilds the main-paper query and PCG figure from the raw JSON files.

audit_reported_results.py
    Checks every number reported in the deep-curvature section and verifies
    that every citation key in main.tex exists in references.bib.

hessian_case_study.py
    Runs the smaller environment-light digits mechanism check.

make_figure.py
    Reproduces the supplementary coordinate-family mechanism figure from
    scratch. The script fixes all random seeds and writes fiber_tradeoff.pdf.

verify_fiber_regression.py
    Constructs random, row-supported, arrowhead, diagonal, and block linear
    matrix families. It projects residuals onto the orthogonal complement of
    each family, runs spectral fiber regression, and reports relative error and
    empirical Hessian diagnostics. It also uses a residual aligned with the top
    eigenvector of the low-fiber variance proxy.

verify_two_projector.py
    Checks the exact three-block population identity, coefficient Gram identity,
    and self-adjoint reuse of the same products for the two-projector estimator.

verification_output.txt
    Records the commands and aggregate checks used in the paper.

Requirements
------------
Python 3.10 or later, NumPy, SciPy, Matplotlib, scikit-learn, PyTorch 2.6.0,
and torchvision 0.21.0. CPU execution is sufficient.

Typical commands
----------------
python historical_curvature_study.py --train-count 4000 --test-count 1000 \
    --reference-count 1500 --target-count 1500 --feature-modes 8 \
    --dictionary 128 --subset-size 375 --budgets 12 16 24 32 48 64 72 \
    --trials 30 --precondition-budget 48 --lanczos-steps 150 \
    --norm-probes 64 --seed 2027 --data-seed 2027 \
    --output historical_full_modes8_lanczos150_results.json

python make_deep_figure.py

python audit_reported_results.py

python hessian_case_study.py --trials 80 --output hessian_case_study.pdf

python verify_two_projector.py

python make_figure.py

python verify_fiber_regression.py --n 20 --q 72 --epsilon 0.2 \
    --multiplier 2 --trials 40 --seed 7

python verify_fiber_regression.py --n 18 --q 64 --epsilon 0.1 \
    --multiplier 2 --trials 30 --seed 11

The scripts are diagnostic checks. No numerical output is used in a proof.
