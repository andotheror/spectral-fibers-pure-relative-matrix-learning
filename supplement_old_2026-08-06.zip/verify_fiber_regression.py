"""Numerical checks for the mixed deterministic/random fiber regression estimator."""

from __future__ import annotations

import argparse
import json

import numpy as np


def orthonormalize(matrices: np.ndarray, tol: float = 1e-10) -> np.ndarray:
    n1, n2 = matrices.shape[1:]
    flat = matrices.reshape(len(matrices), -1).T
    q, r = np.linalg.qr(flat)
    rank = int(np.sum(np.abs(np.diag(r)) > tol))
    return q[:, :rank].T.reshape(rank, n1, n2)


def make_basis(kind: str, n: int, q: int, rng: np.random.Generator) -> np.ndarray:
    if kind == "random":
        return orthonormalize(rng.normal(size=(q, n, n)))
    if kind == "row":
        mats = np.zeros((n, n, n))
        for j in range(n):
            mats[j, 0, j] = 1.0
        return mats
    if kind == "arrow":
        mats = []
        for j in range(n):
            x = np.zeros((n, n))
            x[0, j] = 1.0
            mats.append(x)
        for i in range(1, n):
            x = np.zeros((n, n))
            x[i, 0] = 1.0
            mats.append(x)
        return np.asarray(mats)
    if kind == "diagonal":
        mats = np.zeros((n, n, n))
        for i in range(n):
            mats[i, i, i] = 1.0
        return mats
    if kind == "block":
        k = int(np.floor(np.sqrt(q)))
        mats = []
        for i in range(k):
            for j in range(k):
                x = np.zeros((n, n))
                x[i, j] = 1.0
                mats.append(x)
        return np.asarray(mats)
    raise ValueError(kind)


def partial_trace(basis: np.ndarray) -> np.ndarray:
    return np.einsum("iab,icb->ac", basis, basis)


def project_out(matrix: np.ndarray, basis: np.ndarray) -> np.ndarray:
    coefficients = np.einsum("iab,ab->i", basis, matrix)
    return matrix - np.einsum("i,iab->ab", coefficients, basis)


def worst_low_residual(basis: np.ndarray, tau: float) -> np.ndarray:
    """Maximize the partial-trace variance proxy over residuals orthogonal to L."""
    n1, n2 = basis.shape[1:]
    k = partial_trace(basis)
    eigvals, eigvecs = np.linalg.eigh(k)
    y = eigvecs[:, eigvals > tau]
    projector = np.eye(n1) - y @ y.T
    low_k = projector @ k @ projector

    flat_basis = basis.reshape(len(basis), -1).T
    residual_projector = np.eye(n1 * n2) - flat_basis @ flat_basis.T
    # NumPy's row-major vectorization makes left multiplication by low_k equal
    # to kron(low_k, I). Restrict that PSD operator to L's orthogonal complement.
    variance_operator = residual_projector @ np.kron(low_k, np.eye(n2))
    variance_operator = variance_operator @ residual_projector
    values, vectors = np.linalg.eigh(variance_operator)
    residual = vectors[:, -1].reshape(n1, n2)
    residual = project_out(residual, basis)
    return residual / np.linalg.norm(residual)


def estimate(
    target: np.ndarray,
    basis: np.ndarray,
    tau: float,
    m: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, dict]:
    n = target.shape[0]
    k = partial_trace(basis)
    eigvals, eigvecs = np.linalg.eigh(k)
    high = eigvals > tau
    y = eigvecs[:, high]
    projector = np.eye(n) - y @ y.T
    xs = rng.normal(size=(n, m))

    # Design rows are formed explicitly only for this diagnostic.
    high_response = (y.T @ target).reshape(-1) if y.size else np.zeros(0)
    # Each high output coordinate has an n-vector response, so construct its
    # matching coefficient design without ambiguous tensor reshaping.
    if y.size:
        high_design = np.stack([(y.T @ p).reshape(-1) for p in basis], axis=1)
    else:
        high_design = np.zeros((0, len(basis)))

    low_target = projector @ target @ xs / np.sqrt(m)
    low_design = np.stack(
        [(projector @ p @ xs / np.sqrt(m)).reshape(-1) for p in basis], axis=1
    )
    design = np.vstack([high_design, low_design])
    response = np.concatenate([high_response, low_target.reshape(-1)])
    coefficients, *_ = np.linalg.lstsq(design, response, rcond=None)
    fitted = np.einsum("i,iab->ab", coefficients, basis)
    gram = design.T @ design
    return fitted, {
        "high_dimension": int(high.sum()),
        "min_gram_eigenvalue": float(np.linalg.eigvalsh(gram)[0]),
        "max_gram_eigenvalue": float(np.linalg.eigvalsh(gram)[-1]),
        "max_low_partial_trace": float(
            np.linalg.eigvalsh(projector @ k @ projector)[-1]
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=24)
    parser.add_argument("--q", type=int, default=100)
    parser.add_argument("--epsilon", type=float, default=0.2)
    parser.add_argument("--multiplier", type=float, default=16.0)
    parser.add_argument("--trials", type=int, default=50)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    rng = np.random.default_rng(args.seed)
    rows = []
    for kind in ["random", "row", "arrow", "diagonal", "block"]:
        basis = make_basis(kind, args.n, min(args.q, args.n * args.n), rng)
        q = len(basis)
        tau = max(1.0, np.sqrt(q * args.epsilon))
        m = int(np.ceil(args.multiplier * tau / args.epsilon))
        ratios = []
        adversarial_ratios = []
        gram_mins = []
        high_dimensions = []
        adversarial_residual = worst_low_residual(basis, tau)
        for _ in range(args.trials):
            signal_coefficients = rng.normal(size=q)
            signal = np.einsum("i,iab->ab", signal_coefficients, basis)
            residual = project_out(rng.normal(size=(args.n, args.n)), basis)
            residual /= np.linalg.norm(residual)
            target = signal + residual
            fitted, diagnostics = estimate(target, basis, tau, m, rng)
            error = np.linalg.norm(target - fitted)
            ratios.append(error / np.linalg.norm(residual))
            gram_mins.append(diagnostics["min_gram_eigenvalue"])
            high_dimensions.append(diagnostics["high_dimension"])

            adversarial_target = signal + adversarial_residual
            adversarial_fit, _ = estimate(
                adversarial_target, basis, tau, m, rng
            )
            adversarial_ratios.append(
                np.linalg.norm(adversarial_target - adversarial_fit)
            )
        rows.append(
            {
                "kind": kind,
                "q": q,
                "tau": tau,
                "random_right_queries": m,
                "high_left_queries": int(max(high_dimensions)),
                "mean_error_ratio": float(np.mean(ratios)),
                "max_error_ratio": float(np.max(ratios)),
                "mean_adversarial_ratio": float(np.mean(adversarial_ratios)),
                "max_adversarial_ratio": float(np.max(adversarial_ratios)),
                "random_successes": int(
                    np.sum(np.asarray(ratios) <= 1.0 + args.epsilon)
                ),
                "adversarial_successes": int(
                    np.sum(np.asarray(adversarial_ratios) <= 1.0 + args.epsilon)
                ),
                "min_gram_eigenvalue": float(np.min(gram_mins)),
                "target_ratio": 1.0 + args.epsilon,
            }
        )
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
