"""Assert every numeric claim used in the deep-curvature section."""

from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def load(name: str) -> dict:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def percent(value: float, digits: int = 3) -> float:
    return round(100.0 * value, digits)


main = load("historical_full_modes8_results.json")
high = load("historical_full_modes8_highbudget_results.json")
long = load("historical_full_modes8_lanczos150_results.json")
ekfac = load("historical_full_modes8_ekfac_baseline_results.json")
seeds = {
    seed: load(f"historical_full_modes8_seed{seed}_results.json")
    for seed in (3, 11, 29)
}

assert main["hessian_dimension"] == 5770
assert main["reduced_dimension"] == 72
assert main["family_dimension"] == 128
assert main["reference_examples"] == main["target_examples"] == 1500
assert main["subset_size"] == 375
assert main["dictionary_atoms"] == 128
assert main["test_accuracy"] == 0.827

q48 = main["query_results"]["48"]
assert percent(q48["fiber_projection_excess_median"]) == 0.378
assert percent(q48["gaussian_projection_excess_median"]) == 1.220
assert percent(high["query_results"]["128"]["gaussian_projection_excess_median"]) == 0.434
assert q48["fiber_projection_excess_median"] < high["query_results"]["128"]["gaussian_projection_excess_median"]

expected = {
    3: (0.243, 1.081, 0.399),
    11: (0.400, 0.946, 0.367),
    29: (0.268, 1.111, 0.408),
}
for seed, result in seeds.items():
    got = (
        percent(result["query_results"]["48"]["fiber_projection_excess_median"]),
        percent(result["query_results"]["48"]["gaussian_projection_excess_median"]),
        percent(result["query_results"]["128"]["gaussian_projection_excess_median"]),
    )
    assert got == expected[seed]
    assert result["query_results"]["48"]["fiber_projection_excess_median"] < result["query_results"]["48"]["gaussian_projection_excess_median"]

assert sum(
    result["query_results"]["48"]["fiber_projection_excess_median"]
    < result["query_results"]["128"]["gaussian_projection_excess_median"]
    for result in seeds.values()
) == 2

pcg = long["condition_results"]
assert pcg["spectral_fibers"]["pcg_iterations_median"] == 152
assert pcg["gaussian"]["pcg_iterations_median"] == 153
assert pcg["family_oracle"]["pcg_iterations_median"] == 153
assert pcg["target_kfac"]["pcg_iterations_median"] == 186
assert pcg["target_ekfac"]["pcg_iterations_median"] == 171
assert pcg["none"]["pcg_iterations_median"] == 162
assert pcg["target_jacobi"]["pcg_iterations_median"] == 248
assert [round(pcg[key]["ritz_condition"]) for key in (
    "spectral_fibers", "gaussian", "family_oracle", "target_ekfac",
    "target_kfac", "none", "target_jacobi"
)] == [648, 645, 649, 722, 946, 1093, 3530]
assert pcg["spectral_fibers"]["clipped_eigenvalues"] == 0
assert pcg["gaussian"]["clipped_eigenvalues"] == 0
assert pcg["family_oracle"]["clipped_eigenvalues"] == 0
assert ekfac["condition_results"]["target_ekfac"]["pcg_iterations_median"] == 171

assert round(100 * long["family_explained_residual_fraction"], 2) == 0.20
assert round(long["residual_frobenius_squared_estimate"], 1) == 10014.8
assert round(long["residual_frobenius_standard_error"], 1) == 115.8
assert round(long["family_projection_energy"], 2) == 20.31

tex = (ROOT / "main.tex").read_text(encoding="utf-8")
bib = (ROOT / "references.bib").read_text(encoding="utf-8")
cited = set()
for group in re.findall(r"\\cite[pt]?\{([^}]+)\}", tex):
    cited.update(key.strip() for key in group.split(","))
available = set(re.findall(r"@[A-Za-z]+\{([^,]+),", bib))
assert cited <= available, f"Missing BibTeX keys: {sorted(cited - available)}"

print("Deep-curvature numbers and all citation keys pass.")
