"""Build the MobileNet Hessian query and PCG summary figure."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent


def load(name: str) -> dict:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


main = load("historical_full_modes8_results.json")
high = load("historical_full_modes8_highbudget_results.json")
ekfac = load("historical_full_modes8_ekfac_baseline_results.json")

budgets = np.array([12, 16, 24, 32, 48, 64, 72])
fiber = np.array(
    [main["query_results"][str(k)]["fiber_projection_excess_median"] for k in budgets]
)
fiber_p90 = np.array(
    [main["query_results"][str(k)]["fiber_projection_excess_p90"] for k in budgets]
)
gaussian_budgets = np.array([12, 16, 24, 32, 48, 64, 72, 80, 96, 128])
gaussian = np.array(
    [
        (main if k <= 72 else high)["query_results"][str(k)][
            "gaussian_projection_excess_median"
        ]
        for k in gaussian_budgets
    ]
)
gaussian_p90 = np.array(
    [
        (main if k <= 72 else high)["query_results"][str(k)][
            "gaussian_projection_excess_p90"
        ]
        for k in gaussian_budgets
    ]
)

plt.rcParams.update(
    {
        "font.size": 8.2,
        "axes.labelsize": 8.6,
        "axes.titlesize": 8.8,
        "legend.fontsize": 7.5,
        "xtick.labelsize": 7.6,
        "ytick.labelsize": 7.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
)

blue = "#2463A6"
orange = "#D46A1F"
gray = "#6C757D"
fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.35), gridspec_kw={"width_ratios": [1.2, 1.0]})

ax = axes[0]
ax.plot(gaussian_budgets, 100 * gaussian, "o-", color=gray, lw=1.5, ms=3.6, label="Gaussian probing")
ax.fill_between(
    gaussian_budgets,
    100 * gaussian,
    100 * gaussian_p90,
    color=gray,
    alpha=0.16,
    linewidth=0,
)
ax.plot(budgets, 100 * fiber, "o-", color=blue, lw=1.8, ms=3.8, label="Spectral fibers")
ax.fill_between(
    budgets,
    100 * fiber,
    100 * fiber_p90,
    color=blue,
    alpha=0.16,
    linewidth=0,
)
ax.scatter([48, 128], [100 * fiber[budgets.tolist().index(48)], 100 * gaussian[-1]], s=25, facecolors="white", edgecolors=[blue, gray], linewidths=1.3, zorder=5)
ax.annotate("48 HVPs", (48, 100 * fiber[budgets.tolist().index(48)]), xytext=(6, -13), textcoords="offset points", color=blue)
ax.annotate("128 HVPs", (128, 100 * gaussian[-1]), xytext=(-37, 8), textcoords="offset points", color=gray)
ax.set_yscale("log")
ax.set_xlabel("target Hessian-vector products")
ax.set_ylabel("excess over family oracle (%)")
ax.set_title("Reusable curvature correction")
ax.grid(True, which="both", axis="y", alpha=0.22, linewidth=0.55)
ax.legend(frameon=False, loc="upper right")

ax = axes[1]
labels = ["None", "Jacobi", "K-FAC", "EK-FAC", "Gauss.\n48", "Fiber\n48", "Oracle"]
counts = [
    main["condition_results"]["none"]["pcg_iterations_median"],
    main["condition_results"]["target_jacobi"]["pcg_iterations_median"],
    main["condition_results"]["target_kfac"]["pcg_iterations_median"],
    ekfac["condition_results"]["target_ekfac"]["pcg_iterations_median"],
    main["condition_results"]["gaussian"]["pcg_iterations_median"],
    main["condition_results"]["spectral_fibers"]["pcg_iterations_median"],
    main["condition_results"]["family_oracle"]["pcg_iterations_median"],
]
colors = ["#B8B8B8", "#B8B8B8", orange, "#E59A61", gray, blue, "#5B8E5A"]
x = np.arange(len(labels))
bars = ax.bar(x, counts, color=colors, width=0.72)
for bar, value in zip(bars, counts):
    ax.text(bar.get_x() + bar.get_width() / 2, value + 4, f"{value:.0f}", ha="center", va="bottom", fontsize=7.2)
ax.set_xticks(x, labels)
ax.tick_params(axis="x", labelsize=7.0)
ax.set_ylim(0, 280)
ax.set_ylabel("median PCG iterations")
ax.set_title(r"Solve $Hu=b$ to relative residual $10^{-6}$")
ax.grid(True, axis="y", alpha=0.22, linewidth=0.55)
ax.set_axisbelow(True)

fig.tight_layout(w_pad=1.35)
fig.savefig(ROOT / "deep_hessian_study.pdf", bbox_inches="tight")
fig.savefig(ROOT / "deep_hessian_study.png", dpi=220, bbox_inches="tight")
