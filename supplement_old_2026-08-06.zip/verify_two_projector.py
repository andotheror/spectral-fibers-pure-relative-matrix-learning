"""Deterministic and Monte Carlo checks for the v2 two-projector identities."""

from __future__ import annotations

import numpy as np


def orthonormal_columns(matrix: np.ndarray) -> np.ndarray:
    return np.linalg.qr(matrix, mode="reduced")[0]


def rectangular_check(rng: np.random.Generator):
    n1, n2, q = 14, 11, 20
    flat = orthonormal_columns(rng.standard_normal((n1 * n2, q)))
    basis = flat.T.reshape(q, n1, n2)
    left = orthonormal_columns(rng.standard_normal((n1, 3)))
    right = orthonormal_columns(rng.standard_normal((n2, 2)))
    pi_left = np.eye(n1) - left @ left.T
    pi_right = np.eye(n2) - right @ right.T
    residual = np.einsum(
        "ab,ibc,cd->iad", pi_left, basis, pi_right, optimize=True
    )

    # The explicit blocks are kept separate to make dimension mistakes visible.
    left_blocks = np.einsum("ab,ibc->iac", left.T, basis)
    right_blocks = np.einsum("ab,ibc,cd->iad", pi_left, basis, right)
    exact_gram = np.einsum("iab,jab->ij", left_blocks, left_blocks)
    exact_gram += np.einsum("iab,jab->ij", right_blocks, right_blocks)
    residual_gram = np.einsum("iab,jab->ij", residual, residual)
    gram_error = np.linalg.norm(exact_gram + residual_gram - np.eye(q), 2)

    population_error = 0.0
    for _ in range(100):
        matrix = rng.standard_normal((n1, n2))
        lhs = np.linalg.norm(left.T @ matrix, "fro") ** 2
        lhs += np.linalg.norm(pi_left @ matrix @ right, "fro") ** 2
        lhs += np.linalg.norm(pi_left @ matrix @ pi_right, "fro") ** 2
        rhs = np.linalg.norm(matrix, "fro") ** 2
        population_error = max(population_error, abs(lhs - rhs) / rhs)
    return gram_error, population_error


def symmetric_check(rng: np.random.Generator):
    dimension, q, rank = 12, 24, 4
    raw = rng.standard_normal((q, dimension, dimension))
    raw = (raw + raw.transpose(0, 2, 1)) / 2
    flat = orthonormal_columns(raw.reshape(q, -1).T)
    basis = flat.T.reshape(q, dimension, dimension)
    high = orthonormal_columns(rng.standard_normal((dimension, rank)))
    complement = np.eye(dimension) - high @ high.T
    residual = np.einsum(
        "ab,ibc,cd->iad", complement, basis, complement, optimize=True
    )
    left_blocks = np.einsum("ab,ibc->iac", high.T, basis)
    cross_blocks = np.einsum(
        "ab,ibc,cd->iad", complement, basis, high, optimize=True
    )
    gram = np.einsum("iab,jab->ij", left_blocks, left_blocks)
    gram += np.einsum("iab,jab->ij", cross_blocks, cross_blocks)
    gram += np.einsum("iab,jab->ij", residual, residual)
    gram_error = np.linalg.norm(gram - np.eye(q), 2)

    target = rng.standard_normal((dimension, dimension))
    target = (target + target.T) / 2
    products = target @ high
    observation_error = max(
        np.linalg.norm(high.T @ target - products.T, "fro"),
        np.linalg.norm(complement @ target @ high - complement @ products, "fro"),
    )
    return gram_error, observation_error


def zero_residual_check(rng: np.random.Generator):
    dimension, rank = 10, 2
    matrices = []
    for i in range(rank):
        matrix = np.zeros((dimension, dimension))
        matrix[i, i] = 1.0
        matrices.append(matrix)
    for i in range(dimension):
        for j in range(i + 1, dimension):
            if i >= rank and j >= rank:
                continue
            matrix = np.zeros((dimension, dimension))
            matrix[i, j] = matrix[j, i] = 1.0 / np.sqrt(2.0)
            matrices.append(matrix)
    basis = np.stack(matrices)
    high = np.eye(dimension)[:, :rank]
    complement = np.eye(dimension) - high @ high.T
    residual = np.einsum(
        "ab,ibc,cd->iad", complement, basis, complement, optimize=True
    )

    target = rng.standard_normal((dimension, dimension))
    target = (target + target.T) / 2
    left_design = np.stack([high.T @ matrix for matrix in basis], axis=-1)
    cross_design = np.stack(
        [complement @ matrix @ high for matrix in basis], axis=-1
    )
    design = np.concatenate(
        [
            left_design.reshape(rank * dimension, len(basis)),
            cross_design.reshape(dimension * rank, len(basis)),
        ]
    )
    response = np.concatenate(
        [
            (high.T @ target).reshape(rank * dimension),
            (complement @ target @ high).reshape(dimension * rank),
        ]
    )
    fitted = np.linalg.lstsq(design, response, rcond=None)[0]
    optimum = np.einsum("iab,ab->i", basis, target)
    return np.linalg.norm(residual), np.linalg.norm(fitted - optimum)


def main():
    rng = np.random.default_rng(20260806)
    rectangular_gram, population = rectangular_check(rng)
    symmetric_gram, observation = symmetric_check(rng)
    residual_norm, exact_coefficient_error = zero_residual_check(rng)
    print(f"rectangular_gram_spectral_error={rectangular_gram:.12e}")
    print(f"max_population_relative_error={population:.12e}")
    print(f"symmetric_gram_spectral_error={symmetric_gram:.12e}")
    print(f"same_products_observation_error={observation:.12e}")
    print(f"zero_residual_basis_norm={residual_norm:.12e}")
    print(f"zero_random_query_coefficient_error={exact_coefficient_error:.12e}")


if __name__ == "__main__":
    main()
