"""Deep-network curvature study for a possible FiberRegression_v3.

The script freezes an ImageNet-pretrained MobileNetV3-Small backbone, fits a
ten-class CIFAR-10 linear head, and treats the head Hessian as an HVP oracle.
The approximation family is the span of selected empirical-Fisher atoms.  All
large matrices are kept implicit.  Exact reduced matrices are formed only for
evaluation and never supplied to either query estimator.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import Tensor
from torch.utils.data import DataLoader, Subset
from torchvision.datasets import CIFAR10
from torchvision.models import MobileNet_V3_Small_Weights, mobilenet_v3_small


def seed_everything(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)


@torch.inference_mode()
def extract_features(
    data_root: Path,
    cache_path: Path,
    train_count: int,
    test_count: int,
    seed: int,
) -> tuple[Tensor, Tensor, Tensor, Tensor, dict[str, float]]:
    if cache_path.exists():
        payload = torch.load(cache_path, map_location="cpu", weights_only=True)
        metadata = {
            "feature_seconds": 0.0,
            "feature_cache_hit": 1.0,
        }
        return (
            payload["train_features"].double(),
            payload["train_labels"].long(),
            payload["test_features"].double(),
            payload["test_labels"].long(),
            metadata,
        )

    weights = MobileNet_V3_Small_Weights.DEFAULT
    transform = weights.transforms()
    train_data = CIFAR10(data_root, train=True, transform=transform, download=True)
    test_data = CIFAR10(data_root, train=False, transform=transform, download=True)
    rng = np.random.default_rng(seed)
    train_indices = rng.choice(len(train_data), train_count, replace=False)
    test_indices = rng.choice(len(test_data), test_count, replace=False)
    train_loader = DataLoader(
        Subset(train_data, train_indices.tolist()), batch_size=64, shuffle=False,
        num_workers=0,
    )
    test_loader = DataLoader(
        Subset(test_data, test_indices.tolist()), batch_size=64, shuffle=False,
        num_workers=0,
    )

    model = mobilenet_v3_small(weights=weights).eval()

    def run(loader: DataLoader) -> tuple[Tensor, Tensor]:
        feature_batches = []
        label_batches = []
        for images, labels in loader:
            hidden = model.features(images)
            hidden = model.avgpool(hidden)
            feature_batches.append(torch.flatten(hidden, 1).cpu())
            label_batches.append(labels.cpu())
        return torch.cat(feature_batches), torch.cat(label_batches)

    start = time.perf_counter()
    train_features, train_labels = run(train_loader)
    test_features, test_labels = run(test_loader)
    elapsed = time.perf_counter() - start
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "train_features": train_features.float(),
            "train_labels": train_labels,
            "test_features": test_features.float(),
            "test_labels": test_labels,
        },
        cache_path,
    )
    return (
        train_features.double(),
        train_labels,
        test_features.double(),
        test_labels,
        {"feature_seconds": elapsed, "feature_cache_hit": 0.0},
    )


def standardize_and_append_bias(
    train_features: Tensor, test_features: Tensor
) -> tuple[Tensor, Tensor]:
    mean = train_features.mean(0, keepdim=True)
    scale = train_features.std(0, keepdim=True).clamp_min(1e-5)
    train = (train_features - mean) / scale
    test = (test_features - mean) / scale
    train = torch.cat([train, torch.ones(len(train), 1)], dim=1)
    test = torch.cat([test, torch.ones(len(test), 1)], dim=1)
    return train, test


def fit_head(
    features: Tensor, labels: Tensor, classes: int, ridge: float
) -> tuple[Tensor, dict[str, float]]:
    weights = torch.zeros(classes, features.shape[1], requires_grad=True)
    optimizer = torch.optim.LBFGS(
        [weights], lr=1.0, max_iter=80, tolerance_grad=1e-9,
        tolerance_change=1e-11, line_search_fn="strong_wolfe",
    )
    calls = 0

    def closure() -> Tensor:
        nonlocal calls
        optimizer.zero_grad()
        logits = features @ weights.T
        loss = F.cross_entropy(logits, labels) + 0.5 * ridge * weights.square().sum()
        loss.backward()
        calls += 1
        return loss

    start = time.perf_counter()
    optimizer.step(closure)
    seconds = time.perf_counter() - start
    with torch.no_grad():
        loss = F.cross_entropy(features @ weights.T, labels).item()
        accuracy = (features @ weights.T).argmax(1).eq(labels).double().mean().item()
    return weights.detach(), {
        "head_fit_seconds": seconds,
        "head_closure_calls": float(calls),
        "train_cross_entropy": loss,
        "train_accuracy": accuracy,
    }


class HeadHessian:
    def __init__(self, features: Tensor, probabilities: Tensor, ridge: float):
        self.features = features
        self.probabilities = probabilities
        self.ridge = ridge
        self.classes = probabilities.shape[1]
        self.feature_dim = features.shape[1]
        self.dimension = self.classes * self.feature_dim

    def data_product(self, vector: Tensor) -> Tensor:
        matrix = vector.reshape(self.classes, self.feature_dim)
        logit_shift = self.features @ matrix.T
        weighted = self.probabilities * logit_shift
        centered = weighted - self.probabilities * weighted.sum(1, keepdim=True)
        output = centered.T @ self.features / len(self.features)
        return output.reshape(-1)

    def product(self, vector: Tensor) -> Tensor:
        return self.data_product(vector) + self.ridge * vector


def per_example_gradients(
    features: Tensor, probabilities: Tensor, labels: Tensor
) -> Tensor:
    residual = probabilities.clone()
    residual[torch.arange(len(labels)), labels] -= 1.0
    return torch.einsum("nc,nd->ncd", residual, features).reshape(len(features), -1)


def select_dictionary(gradients: Tensor, count: int, seed: int) -> tuple[Tensor, Tensor]:
    rng = np.random.default_rng(seed)
    norms = gradients.norm(dim=1)
    weights = (norms.square() / norms.square().sum()).cpu().numpy()
    indices = rng.choice(len(gradients), size=count, replace=False, p=weights)
    raw = gradients[torch.from_numpy(indices)]
    normalized = raw / raw.norm(dim=1, keepdim=True).clamp_min(1e-12)
    return normalized.T.contiguous(), torch.from_numpy(indices)


def atom_basis(dictionary: Tensor, tolerance: float = 1e-9) -> tuple[Tensor, Tensor, Tensor]:
    support, coordinates = torch.linalg.qr(dictionary, mode="reduced")
    diagonal = torch.abs(torch.diag(coordinates))
    rank = int((diagonal > tolerance * diagonal.max()).sum().item())
    support = support[:, :rank]
    coordinates = support.T @ dictionary
    atoms = torch.einsum("ri,si->irs", coordinates, coordinates)
    flat_atoms = atoms.reshape(atoms.shape[0], -1)
    _, singular, right = torch.linalg.svd(flat_atoms, full_matrices=False)
    family_rank = int((singular > tolerance * singular.max()).sum().item())
    basis = right[:family_rank].reshape(family_rank, rank, rank)
    return support, coordinates, basis


def residual_profiles(basis: Tensor, max_rank: int) -> tuple[Tensor, Tensor, list[tuple[float, float]]]:
    q, dimension, _ = basis.shape
    partial_trace = torch.einsum("iab,icb->ac", basis, basis)
    eigenvalues, eigenvectors = torch.linalg.eigh(partial_trace)
    order = torch.argsort(eigenvalues, descending=True)
    eigenvalues = eigenvalues[order]
    eigenvectors = eigenvectors[:, order]
    identity = torch.eye(dimension)
    profiles = []
    for exact_rank in range(max_rank + 1):
        high = eigenvectors[:, :exact_rank]
        complement = identity - high @ high.T
        residual = torch.einsum("ab,ibc,cd->iad", complement, basis, complement)
        gamma_matrix = torch.einsum("iab,icb->ac", residual, residual)
        gamma = torch.linalg.eigvalsh(gamma_matrix)[-1].item()
        flat = residual.reshape(q, -1)
        beta = torch.linalg.eigvalsh(flat @ flat.T)[-1].item()
        profiles.append((gamma, beta))
    return eigenvalues, eigenvectors, profiles


def choose_exact_rank(
    budget: int, profiles: list[tuple[float, float]], dimension: int, q: int
) -> int:
    scores = []
    for exact_rank in range(min(budget, dimension) + 1):
        gamma, beta = profiles[exact_rank]
        sigma2 = max(gamma, beta)
        logs = math.log(2 * q) * math.log(
            2 * (dimension + q) * (1 + sigma2) * math.log(2 * q)
        )
        random_count = budget - exact_rank
        if random_count == 0:
            score = 0.0 if gamma + sigma2 * logs < 1e-20 else math.inf
        else:
            score = (gamma + sigma2 * logs) / random_count
        scores.append((score, exact_rank))
    return min(scores)[1]


def matrix_from_coefficients(coefficients: Tensor, basis: Tensor) -> Tensor:
    return torch.einsum("i,iab->ab", coefficients, basis)


def gaussian_regression(
    target: Tensor, basis: Tensor, budget: int, generator: torch.Generator
) -> Tensor:
    q, dimension, _ = basis.shape
    probes = torch.randn(dimension, budget, generator=generator)
    design = torch.einsum("iab,bm->mai", basis, probes)
    response = target @ probes
    coefficients = torch.linalg.lstsq(
        design.reshape(budget * dimension, q), response.T.reshape(-1, 1)
    ).solution[:, 0]
    return matrix_from_coefficients(coefficients, basis)


def symmetric_fiber_regression(
    target: Tensor,
    basis: Tensor,
    eigenvectors: Tensor,
    budget: int,
    exact_rank: int,
    generator: torch.Generator,
) -> Tensor:
    q, dimension, _ = basis.shape
    high = eigenvectors[:, :exact_rank]
    complement = torch.eye(dimension) - high @ high.T
    designs = []
    responses = []
    if exact_rank:
        left_design = torch.einsum("ra,iab->rbi", high.T, basis)
        cross_design = torch.einsum("ab,ibc,cr->ari", complement, basis, high)
        designs.extend(
            [left_design.reshape(-1, q), cross_design.reshape(-1, q)]
        )
        responses.extend(
            [(high.T @ target).reshape(-1), (complement @ target @ high).reshape(-1)]
        )
    random_count = budget - exact_rank
    if random_count:
        probes = complement @ torch.randn(dimension, random_count, generator=generator)
        random_design = torch.einsum("ab,ibc,cm->mai", complement, basis, probes)
        scale = 1.0 / math.sqrt(random_count)
        designs.append(scale * random_design.reshape(-1, q))
        responses.append(scale * (complement @ target @ probes).T.reshape(-1))
    coefficients = torch.linalg.lstsq(
        torch.cat(designs), torch.cat(responses)[:, None]
    ).solution[:, 0]
    return matrix_from_coefficients(coefficients, basis)


def full_data_frobenius_norm(features: Tensor, probabilities: Tensor) -> float:
    feature_gram = features @ features.T
    probability_gram = probabilities @ probabilities.T
    left_mixed = probabilities @ probabilities.square().T
    right_mixed = probabilities.square() @ probabilities.T
    class_hessian_gram = (
        probability_gram
        - left_mixed
        - right_mixed
        + probability_gram.square()
    )
    return (class_hessian_gram * feature_gram.square()).mean().item()


def full_error(norm_squared: float, reduced_target: Tensor, estimate: Tensor) -> float:
    return (
        norm_squared
        - 2.0 * torch.sum(reduced_target * estimate).item()
        + estimate.square().sum().item()
    )


def psd_clip(matrix: Tensor) -> Tensor:
    values, vectors = torch.linalg.eigh((matrix + matrix.T) / 2)
    return (vectors * values.clamp_min(0.0)) @ vectors.T


def low_rank_inverse_sqrt(support: Tensor, reduced: Tensor, ridge: float):
    reduced = psd_clip(reduced)
    values, vectors = torch.linalg.eigh(reduced)
    inside = (vectors * (ridge + values).rsqrt()) @ vectors.T
    outside_scale = ridge ** -0.5

    def apply(vector: Tensor) -> Tensor:
        coordinates = support.T @ vector
        return outside_scale * vector + support @ (
            inside @ coordinates - outside_scale * coordinates
        )

    return apply


def lanczos_condition(operator, dimension: int, steps: int, seed: int) -> tuple[float, float, float]:
    generator = torch.Generator().manual_seed(seed)
    vector = torch.randn(dimension, generator=generator)
    vector /= vector.norm()
    vectors = []
    alphas = []
    betas = []
    previous = torch.zeros_like(vector)
    beta_previous = 0.0
    for _ in range(steps):
        vectors.append(vector)
        work = operator(vector) - beta_previous * previous
        alpha = torch.dot(vector, work).item()
        work -= alpha * vector
        for saved in vectors:
            work -= torch.dot(saved, work) * saved
        beta = work.norm().item()
        alphas.append(alpha)
        if beta < 1e-12:
            break
        betas.append(beta)
        previous, vector = vector, work / beta
        beta_previous = beta
    tridiagonal = torch.diag(torch.tensor(alphas))
    if len(alphas) > 1:
        off = torch.tensor(betas[: len(alphas) - 1])
        tridiagonal += torch.diag(off, 1) + torch.diag(off, -1)
    values = torch.linalg.eigvalsh(tridiagonal)
    smallest = values[0].item()
    largest = values[-1].item()
    return smallest, largest, largest / smallest


def run(arguments: argparse.Namespace) -> dict:
    seed_everything(arguments.seed)
    root = Path(__file__).resolve().parent
    os.environ.setdefault("TORCH_HOME", str(root / "torch_cache"))
    cache = root / (
        f"v3_features_train{arguments.train_count}_test{arguments.test_count}_"
        f"seed{arguments.seed}.pt"
    )
    train_x, train_y, test_x, test_y, feature_meta = extract_features(
        root / "data", cache, arguments.train_count, arguments.test_count,
        arguments.seed,
    )
    # ``extract_features`` runs under inference mode.  Clone after leaving that
    # context so that autograd may save the training features during head fitting.
    train_x = train_x.clone()
    train_y = train_y.clone()
    test_x = test_x.clone()
    test_y = test_y.clone()
    torch.set_default_dtype(torch.float64)
    train_x, test_x = standardize_and_append_bias(train_x, test_x)
    head, fit_meta = fit_head(train_x, train_y, 10, arguments.ridge)
    with torch.no_grad():
        train_probabilities = (train_x @ head.T).softmax(1)
        test_accuracy = (test_x @ head.T).argmax(1).eq(test_y).double().mean().item()

    curvature_count = min(arguments.curvature_count, len(train_x))
    curvature_x = train_x[:curvature_count]
    curvature_y = train_y[:curvature_count]
    curvature_p = train_probabilities[:curvature_count]
    hessian = HeadHessian(curvature_x, curvature_p, arguments.ridge)
    gradients = per_example_gradients(curvature_x, curvature_p, curvature_y)
    dictionary, indices = select_dictionary(gradients, arguments.dictionary, arguments.seed + 1)

    preprocessing_start = time.perf_counter()
    support, atom_coordinates, basis = atom_basis(dictionary)
    q, reduced_dimension, _ = basis.shape
    max_budget = max(arguments.budgets)
    eigenvalues, eigenvectors, profiles = residual_profiles(basis, max_budget)
    exact_ranks = [
        choose_exact_rank(budget, profiles, reduced_dimension, q)
        for budget in arguments.budgets
    ]
    preprocessing_seconds = time.perf_counter() - preprocessing_start

    reduced_start = time.perf_counter()
    reduced_columns = []
    for column in range(reduced_dimension):
        reduced_columns.append(support.T @ hessian.data_product(support[:, column]))
    reduced_target = torch.stack(reduced_columns, dim=1)
    reduced_target = (reduced_target + reduced_target.T) / 2
    evaluation_hvps = reduced_dimension
    reduced_seconds = time.perf_counter() - reduced_start

    norm_squared = full_data_frobenius_norm(curvature_x, curvature_p)
    optimum_coefficients = torch.einsum("iab,ab->i", basis, reduced_target)
    optimum = matrix_from_coefficients(optimum_coefficients, basis)
    optimum_error = full_error(norm_squared, reduced_target, optimum)

    trial_results = {}
    selected_estimates = {}
    for budget, exact_rank in zip(arguments.budgets, exact_ranks):
        gaussian_ratios = []
        fiber_ratios = []
        gaussian_times = []
        fiber_times = []
        for trial in range(arguments.trials):
            trial_seed = arguments.seed * 100000 + budget * 100 + trial
            generator = torch.Generator().manual_seed(trial_seed)
            start = time.perf_counter()
            gaussian = gaussian_regression(reduced_target, basis, budget, generator)
            gaussian_times.append(time.perf_counter() - start)
            generator = torch.Generator().manual_seed(trial_seed)
            start = time.perf_counter()
            fiber = symmetric_fiber_regression(
                reduced_target, basis, eigenvectors, budget, exact_rank, generator
            )
            fiber_times.append(time.perf_counter() - start)
            gaussian_ratios.append(
                full_error(norm_squared, reduced_target, gaussian) / optimum_error
            )
            fiber_ratios.append(
                full_error(norm_squared, reduced_target, fiber) / optimum_error
            )
            if trial == 0 and budget == arguments.precondition_budget:
                selected_estimates["gaussian"] = gaussian
                selected_estimates["fiber"] = fiber
        trial_results[str(budget)] = {
            "exact_rank": exact_rank,
            "gaussian_error_median": float(np.median(gaussian_ratios)),
            "gaussian_error_p10": float(np.quantile(gaussian_ratios, 0.1)),
            "gaussian_error_p90": float(np.quantile(gaussian_ratios, 0.9)),
            "fiber_error_median": float(np.median(fiber_ratios)),
            "fiber_error_p10": float(np.quantile(fiber_ratios, 0.1)),
            "fiber_error_p90": float(np.quantile(fiber_ratios, 0.9)),
            "gaussian_regression_seconds_median": float(np.median(gaussian_times)),
            "fiber_regression_seconds_median": float(np.median(fiber_times)),
        }

    if "fiber" not in selected_estimates:
        raise ValueError("precondition budget must be included in budgets")

    preconditioners = {
        "family_oracle": low_rank_inverse_sqrt(support, optimum, arguments.ridge),
        "gaussian": low_rank_inverse_sqrt(
            support, selected_estimates["gaussian"], arguments.ridge
        ),
        "spectral_fibers": low_rank_inverse_sqrt(
            support, selected_estimates["fiber"], arguments.ridge
        ),
    }
    raw_selected = gradients[indices]
    fisher_support, fisher_r = torch.linalg.qr(raw_selected.T, mode="reduced")
    fisher_reduced = fisher_r @ fisher_r.T / len(indices)
    preconditioners["selected_empirical_fisher"] = low_rank_inverse_sqrt(
        fisher_support, fisher_reduced, arguments.ridge
    )
    class_factor = torch.diag(curvature_p.mean(0)) - (
        curvature_p.T @ curvature_p / curvature_count
    )
    feature_factor = curvature_x.T @ curvature_x / curvature_count
    class_values, class_vectors = torch.linalg.eigh(class_factor)
    feature_values, feature_vectors = torch.linalg.eigh(feature_factor)
    kfac_scale = (
        arguments.ridge
        + class_values.clamp_min(0.0)[:, None]
        * feature_values.clamp_min(0.0)[None, :]
    ).rsqrt()

    def kfac_inverse_sqrt(vector: Tensor) -> Tensor:
        matrix = vector.reshape(hessian.classes, hessian.feature_dim)
        coordinates = class_vectors.T @ matrix @ feature_vectors
        return (
            class_vectors @ (kfac_scale * coordinates) @ feature_vectors.T
        ).reshape(-1)

    preconditioners["kfac"] = kfac_inverse_sqrt
    diagonal = arguments.ridge + (
        torch.einsum(
            "nc,nf->ncf",
            curvature_p * (1.0 - curvature_p),
            curvature_x.square(),
        ).mean(0).reshape(-1)
    )

    def jacobi_inverse_sqrt(vector: Tensor) -> Tensor:
        return vector / diagonal.sqrt()

    preconditioners["jacobi"] = jacobi_inverse_sqrt
    preconditioners["none"] = lambda vector: vector

    condition_results = {}
    for name, inverse_sqrt in preconditioners.items():
        start = time.perf_counter()

        def transformed(vector: Tensor) -> Tensor:
            inner = inverse_sqrt(vector)
            return inverse_sqrt(hessian.product(inner))

        smallest, largest, condition = lanczos_condition(
            transformed, hessian.dimension, arguments.lanczos_steps,
            arguments.seed + 200,
        )
        condition_results[name] = {
            "ritz_min": smallest,
            "ritz_max": largest,
            "ritz_condition": condition,
            "lanczos_seconds": time.perf_counter() - start,
        }

    probes = torch.randn(hessian.dimension, 8, generator=torch.Generator().manual_seed(99))
    start = time.perf_counter()
    for column in range(probes.shape[1]):
        hessian.product(probes[:, column])
    hvp_seconds = (time.perf_counter() - start) / probes.shape[1]

    result = {
        "seed": arguments.seed,
        "model": "ImageNet-pretrained MobileNetV3-Small frozen backbone",
        "dataset": "CIFAR-10",
        "train_examples": len(train_x),
        "test_examples": len(test_x),
        "curvature_examples": curvature_count,
        "classes": hessian.classes,
        "feature_dimension_with_bias": hessian.feature_dim,
        "hessian_dimension": hessian.dimension,
        "dictionary_atoms": arguments.dictionary,
        "dictionary_vector_rank": reduced_dimension,
        "family_dimension": q,
        "ridge": arguments.ridge,
        "test_accuracy": test_accuracy,
        "data_hessian_frobenius_squared": norm_squared,
        "family_optimum_error": optimum_error,
        "family_optimum_error_fraction": optimum_error / norm_squared,
        "partial_trace_top10": eigenvalues[:10].tolist(),
        "estimator_trials": arguments.trials,
        "precondition_budget": arguments.precondition_budget,
        "query_results": trial_results,
        "condition_results": condition_results,
        "hvp_seconds": hvp_seconds,
        "family_preprocessing_seconds": preprocessing_seconds,
        "evaluation_only_hvps": evaluation_hvps,
        "evaluation_reduced_matrix_seconds": reduced_seconds,
        **feature_meta,
        **fit_meta,
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return result


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-count", type=int, default=4000)
    parser.add_argument("--test-count", type=int, default=1000)
    parser.add_argument("--curvature-count", type=int, default=1500)
    parser.add_argument("--dictionary", type=int, default=128)
    parser.add_argument("--budgets", type=int, nargs="+", default=[8, 12, 16, 24, 32, 48])
    parser.add_argument("--trials", type=int, default=30)
    parser.add_argument("--precondition-budget", type=int, default=24)
    parser.add_argument("--lanczos-steps", type=int, default=40)
    parser.add_argument("--ridge", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=2027)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().parent / "deep_curvature_results.json",
    )
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_arguments())
