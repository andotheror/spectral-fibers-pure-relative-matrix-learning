"""K-FAC residual study for a possible FiberRegression_v3.

The script whitens a frozen-backbone last-layer Hessian by its K-FAC
approximation, then learns a low-rank correction to the whitened residual.
Only Hessian-vector products are counted as oracle queries.  Exact reduced
matrices and randomized Frobenius estimates are evaluation-only diagnostics.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import Tensor

from deep_curvature_study import (
    HeadHessian,
    atom_basis,
    choose_exact_rank,
    extract_features,
    full_error,
    gaussian_regression,
    lanczos_condition,
    matrix_from_coefficients,
    residual_profiles,
    seed_everything,
    standardize_and_append_bias,
    symmetric_fiber_regression,
)


def fit_head(
    features: Tensor, labels: Tensor, classes: int, ridge: float
) -> tuple[Tensor, dict[str, float]]:
    weights = torch.zeros(classes, features.shape[1], requires_grad=True)
    optimizer = torch.optim.LBFGS(
        [weights], lr=1.0, max_iter=100, tolerance_grad=1e-9,
        tolerance_change=1e-11, line_search_fn="strong_wolfe",
    )
    calls = 0

    def closure() -> Tensor:
        nonlocal calls
        optimizer.zero_grad()
        logits = features @ weights.T
        loss = F.cross_entropy(logits, labels) + 0.5 * ridge * weights.square().sum()
        loss.backward()
        calls += 1
        return loss

    start = time.perf_counter()
    optimizer.step(closure)
    seconds = time.perf_counter() - start
    with torch.no_grad():
        logits = features @ weights.T
        loss = F.cross_entropy(logits, labels).item()
        accuracy = logits.argmax(1).eq(labels).double().mean().item()
    return weights.detach(), {
        "head_fit_seconds": seconds,
        "head_closure_calls": float(calls),
        "train_cross_entropy": loss,
        "train_accuracy": accuracy,
    }


def kfac_inverse_sqrt(
    features: Tensor, probabilities: Tensor, ridge: float
) -> tuple[callable, Tensor, Tensor, Tensor]:
    class_factor = torch.diag(probabilities.mean(0)) - (
        probabilities.T @ probabilities / len(probabilities)
    )
    feature_factor = features.T @ features / len(features)
    class_values, class_vectors = torch.linalg.eigh(class_factor)
    feature_values, feature_vectors = torch.linalg.eigh(feature_factor)
    spectrum = (
        ridge
        + class_values.clamp_min(0.0)[:, None]
        * feature_values.clamp_min(0.0)[None, :]
    )
    inverse_scale = spectrum.rsqrt()

    def apply(vector: Tensor) -> Tensor:
        matrix = vector.reshape(probabilities.shape[1], features.shape[1])
        coordinates = class_vectors.T @ matrix @ feature_vectors
        return (
            class_vectors @ (inverse_scale * coordinates) @ feature_vectors.T
        ).reshape(-1)

    return apply, class_values, feature_values, spectrum


def curvature_dictionary(
    features: Tensor,
    probabilities: Tensor,
    count: int,
    seed: int,
    whiten,
) -> tuple[Tensor, Tensor, Tensor]:
    class_hessians = torch.diag_embed(probabilities) - torch.einsum(
        "ni,nj->nij", probabilities, probabilities
    )
    values, vectors = torch.linalg.eigh(class_hessians)
    values = values.clamp_min(0.0)
    weights = values * features.square().sum(1, keepdim=True)
    flat_weights = weights.reshape(-1)
    valid = flat_weights > 1e-14 * flat_weights.max()
    valid_indices = torch.nonzero(valid, as_tuple=False)[:, 0]
    distribution = flat_weights[valid].cpu().numpy()
    distribution /= distribution.sum()
    rng = np.random.default_rng(seed)
    chosen_local = rng.choice(
        len(valid_indices), size=count, replace=False, p=distribution
    )
    chosen = valid_indices[torch.from_numpy(chosen_local)]
    classes = probabilities.shape[1]
    example_indices = torch.div(chosen, classes, rounding_mode="floor")
    class_indices = chosen.remainder(classes)
    raw_vectors = []
    for example, component in zip(example_indices.tolist(), class_indices.tolist()):
        class_vector = (
            values[example, component].sqrt() * vectors[example, :, component]
        )
        raw_vectors.append(torch.outer(class_vector, features[example]).reshape(-1))
    raw = torch.stack(raw_vectors, dim=1)
    whitened = torch.stack([whiten(raw[:, j]) for j in range(count)], dim=1)
    normalized = whitened / whitened.norm(dim=0, keepdim=True).clamp_min(1e-12)
    return normalized, example_indices, class_indices


def randomized_frobenius_squared(
    operator, dimension: int, probes: int, seed: int
) -> tuple[float, float, float]:
    generator = torch.Generator().manual_seed(seed)
    samples = []
    start = time.perf_counter()
    for _ in range(probes):
        vector = torch.empty(dimension).bernoulli_(0.5, generator=generator)
        vector.mul_(2.0).sub_(1.0)
        samples.append(operator(vector).square().sum().item())
    values = np.asarray(samples)
    standard_error = float(values.std(ddof=1) / math.sqrt(probes)) if probes > 1 else 0.0
    return float(values.mean()), standard_error, time.perf_counter() - start


def identity_plus_low_rank_inverse_sqrt(
    support: Tensor, correction: Tensor, eigenvalue_floor: float
) -> tuple[callable, float, int]:
    matrix = torch.eye(correction.shape[0]) + (correction + correction.T) / 2
    values, vectors = torch.linalg.eigh(matrix)
    minimum = values[0].item()
    clipped = int((values < eigenvalue_floor).sum().item())
    inside = (vectors * values.clamp_min(eigenvalue_floor).rsqrt()) @ vectors.T
    delta = inside - torch.eye(inside.shape[0])

    def apply(vector: Tensor) -> Tensor:
        coordinates = support.T @ vector
        return vector + support @ (delta @ coordinates)

    return apply, minimum, clipped


def run(arguments: argparse.Namespace) -> dict:
    seed_everything(arguments.seed)
    root = Path(__file__).resolve().parent
    os.environ.setdefault("TORCH_HOME", str(root / "torch_cache"))
    cache = root / (
        f"v3_features_train{arguments.train_count}_test{arguments.test_count}_"
        f"seed{arguments.data_seed}.pt"
    )
    train_x, train_y, test_x, test_y, feature_meta = extract_features(
        root / "data", cache, arguments.train_count, arguments.test_count,
        arguments.data_seed,
    )
    train_x, train_y = train_x.clone(), train_y.clone()
    test_x, test_y = test_x.clone(), test_y.clone()
    torch.set_default_dtype(torch.float64)
    train_x, test_x = standardize_and_append_bias(train_x, test_x)
    head, fit_meta = fit_head(train_x, train_y, 10, arguments.ridge)
    with torch.no_grad():
        train_probabilities = (train_x @ head.T).softmax(1)
        test_accuracy = (
            (test_x @ head.T).argmax(1).eq(test_y).double().mean().item()
        )

    curvature_count = min(arguments.curvature_count, len(train_x))
    curvature_x = train_x[:curvature_count]
    curvature_p = train_probabilities[:curvature_count]
    hessian = HeadHessian(curvature_x, curvature_p, arguments.ridge)
    kfac_whiten, class_values, feature_values, kfac_spectrum = kfac_inverse_sqrt(
        curvature_x, curvature_p, arguments.ridge
    )

    def whitened_hessian(vector: Tensor) -> Tensor:
        inner = kfac_whiten(vector)
        return kfac_whiten(hessian.product(inner))

    def residual(vector: Tensor) -> Tensor:
        return whitened_hessian(vector) - vector

    dictionary, example_indices, class_indices = curvature_dictionary(
        curvature_x, curvature_p, arguments.dictionary, arguments.seed + 1,
        kfac_whiten,
    )
    preprocessing_start = time.perf_counter()
    support, _, basis = atom_basis(dictionary)
    family_dimension, reduced_dimension, _ = basis.shape
    max_budget = max(arguments.budgets)
    eigenvalues, eigenvectors, profiles = residual_profiles(basis, max_budget)
    exact_ranks = [
        choose_exact_rank(
            budget, profiles, reduced_dimension, family_dimension
        )
        for budget in arguments.budgets
    ]
    preprocessing_seconds = time.perf_counter() - preprocessing_start

    reduced_start = time.perf_counter()
    reduced_columns = [
        support.T @ residual(support[:, column])
        for column in range(reduced_dimension)
    ]
    reduced_target = torch.stack(reduced_columns, dim=1)
    reduced_target = (reduced_target + reduced_target.T) / 2
    reduced_seconds = time.perf_counter() - reduced_start
    coefficients = torch.einsum("iab,ab->i", basis, reduced_target)
    oracle_correction = matrix_from_coefficients(coefficients, basis)
    projection_energy = coefficients.square().sum().item()
    residual_norm, residual_se, norm_seconds = randomized_frobenius_squared(
        residual, hessian.dimension, arguments.norm_probes, arguments.seed + 17
    )
    optimum_error = residual_norm - projection_energy

    query_results = {}
    selected_estimates = {}
    for budget, exact_rank in zip(arguments.budgets, exact_ranks):
        gaussian_ratios, fiber_ratios = [], []
        gaussian_excess, fiber_excess = [], []
        for trial in range(arguments.trials):
            trial_seed = arguments.seed * 100000 + budget * 100 + trial
            generator = torch.Generator().manual_seed(trial_seed)
            gaussian = gaussian_regression(
                reduced_target, basis, budget, generator
            )
            generator = torch.Generator().manual_seed(trial_seed)
            fiber = symmetric_fiber_regression(
                reduced_target, basis, eigenvectors, budget, exact_rank,
                generator,
            )
            gaussian_error = full_error(residual_norm, reduced_target, gaussian)
            fiber_error = full_error(residual_norm, reduced_target, fiber)
            gaussian_ratios.append(gaussian_error / optimum_error)
            fiber_ratios.append(fiber_error / optimum_error)
            gaussian_excess.append(
                (gaussian - oracle_correction).square().sum().item()
                / max(projection_energy, 1e-30)
            )
            fiber_excess.append(
                (fiber - oracle_correction).square().sum().item()
                / max(projection_energy, 1e-30)
            )
            if trial == 0 and budget == arguments.precondition_budget:
                selected_estimates["gaussian"] = gaussian
                selected_estimates["spectral_fibers"] = fiber
        query_results[str(budget)] = {
            "exact_rank": exact_rank,
            "gaussian_relative_error_median": float(np.median(gaussian_ratios)),
            "fiber_relative_error_median": float(np.median(fiber_ratios)),
            "gaussian_projection_excess_median": float(np.median(gaussian_excess)),
            "fiber_projection_excess_median": float(np.median(fiber_excess)),
            "gaussian_projection_excess_p90": float(np.quantile(gaussian_excess, 0.9)),
            "fiber_projection_excess_p90": float(np.quantile(fiber_excess, 0.9)),
        }

    corrections = {"family_oracle": oracle_correction, **selected_estimates}
    condition_results = {}
    for name, correction in corrections.items():
        correction_whiten, minimum, clipped = identity_plus_low_rank_inverse_sqrt(
            support, correction, arguments.eigenvalue_floor
        )

        def transformed(vector: Tensor) -> Tensor:
            inner = correction_whiten(vector)
            return correction_whiten(whitened_hessian(inner))

        smallest, largest, condition = lanczos_condition(
            transformed, hessian.dimension, arguments.lanczos_steps,
            arguments.seed + 200,
        )
        condition_results[name] = {
            "ritz_min": smallest,
            "ritz_max": largest,
            "ritz_condition": condition,
            "minimum_preclip_eigenvalue": minimum,
            "clipped_eigenvalues": clipped,
        }
    kfac_min, kfac_max, kfac_condition = lanczos_condition(
        whitened_hessian, hessian.dimension, arguments.lanczos_steps,
        arguments.seed + 200,
    )
    condition_results["kfac"] = {
        "ritz_min": kfac_min,
        "ritz_max": kfac_max,
        "ritz_condition": kfac_condition,
    }

    diagonal = arguments.ridge + torch.einsum(
        "nc,nf->ncf",
        curvature_p * (1.0 - curvature_p), curvature_x.square(),
    ).mean(0).reshape(-1)

    def jacobi_transformed(vector: Tensor) -> Tensor:
        inner = vector / diagonal.sqrt()
        return hessian.product(inner) / diagonal.sqrt()

    jacobi_min, jacobi_max, jacobi_condition = lanczos_condition(
        jacobi_transformed, hessian.dimension, arguments.lanczos_steps,
        arguments.seed + 200,
    )
    none_min, none_max, none_condition = lanczos_condition(
        hessian.product, hessian.dimension, arguments.lanczos_steps,
        arguments.seed + 200,
    )
    condition_results["jacobi"] = {
        "ritz_min": jacobi_min,
        "ritz_max": jacobi_max,
        "ritz_condition": jacobi_condition,
    }
    condition_results["none"] = {
        "ritz_min": none_min,
        "ritz_max": none_max,
        "ritz_condition": none_condition,
    }

    result = {
        "seed": arguments.seed,
        "data_seed": arguments.data_seed,
        "model": "ImageNet-pretrained MobileNetV3-Small frozen backbone",
        "dataset": "CIFAR-10",
        "train_examples": len(train_x),
        "test_examples": len(test_x),
        "curvature_examples": curvature_count,
        "hessian_dimension": hessian.dimension,
        "dictionary_atoms": arguments.dictionary,
        "dictionary_vector_rank": reduced_dimension,
        "family_dimension": family_dimension,
        "test_accuracy": test_accuracy,
        "ridge": arguments.ridge,
        "kfac_spectrum_min": kfac_spectrum.min().item(),
        "kfac_spectrum_max": kfac_spectrum.max().item(),
        "class_factor_effective_rank": int((class_values > 1e-10).sum().item()),
        "feature_factor_effective_rank": int((feature_values > 1e-10).sum().item()),
        "residual_frobenius_squared_estimate": residual_norm,
        "residual_frobenius_standard_error": residual_se,
        "family_projection_energy": projection_energy,
        "family_optimum_error_estimate": optimum_error,
        "family_explained_residual_fraction": projection_energy / residual_norm,
        "partial_trace_top10": eigenvalues[:10].tolist(),
        "query_results": query_results,
        "condition_results": condition_results,
        "precondition_budget": arguments.precondition_budget,
        "estimator_trials": arguments.trials,
        "norm_probes": arguments.norm_probes,
        "evaluation_only_hvps": reduced_dimension + arguments.norm_probes,
        "evaluation_reduced_matrix_seconds": reduced_seconds,
        "evaluation_norm_seconds": norm_seconds,
        "family_preprocessing_seconds": preprocessing_seconds,
        "selected_example_indices": example_indices.tolist(),
        "selected_class_components": class_indices.tolist(),
        **feature_meta,
        **fit_meta,
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return result


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-count", type=int, default=4000)
    parser.add_argument("--test-count", type=int, default=1000)
    parser.add_argument("--curvature-count", type=int, default=1500)
    parser.add_argument("--dictionary", type=int, default=128)
    parser.add_argument("--budgets", type=int, nargs="+", default=[8, 12, 16, 24, 32, 48])
    parser.add_argument("--trials", type=int, default=30)
    parser.add_argument("--precondition-budget", type=int, default=24)
    parser.add_argument("--lanczos-steps", type=int, default=40)
    parser.add_argument("--norm-probes", type=int, default=256)
    parser.add_argument("--ridge", type=float, default=1e-3)
    parser.add_argument("--eigenvalue-floor", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=2027)
    parser.add_argument("--data-seed", type=int, default=2027)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().parent / "kfac_residual_results.json",
    )
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_arguments())
