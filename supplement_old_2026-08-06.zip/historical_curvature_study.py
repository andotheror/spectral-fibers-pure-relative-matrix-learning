"""Transfer a curvature family from reference minibatches to a new Hessian.

The experiment fits a linear head on frozen MobileNetV3-Small features.  It
builds K-FAC and a dictionary of reduced curvature deviations from reference
examples, then estimates the best correction for a disjoint target batch using
only target Hessian-vector products.  The family is fixed before target HVPs.
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import torch
from torch import Tensor

from deep_curvature_study import (
    HeadHessian,
    choose_exact_rank,
    extract_features,
    full_error,
    gaussian_regression,
    lanczos_condition,
    matrix_from_coefficients,
    residual_profiles,
    seed_everything,
    standardize_and_append_bias,
    symmetric_fiber_regression,
)
from kfac_residual_study import (
    fit_head,
    identity_plus_low_rank_inverse_sqrt,
    randomized_frobenius_squared,
)


def kfac_geometry(
    features: Tensor,
    probabilities: Tensor,
    ridge: float,
    feature_modes: int,
) -> tuple[callable, callable, Tensor, Tensor, dict[str, float]]:
    class_factor = torch.diag(probabilities.mean(0)) - (
        probabilities.T @ probabilities / len(probabilities)
    )
    feature_factor = features.T @ features / len(features)
    class_values, class_vectors = torch.linalg.eigh(class_factor)
    feature_values, feature_vectors = torch.linalg.eigh(feature_factor)
    class_order = torch.argsort(class_values, descending=True)
    feature_order = torch.argsort(feature_values, descending=True)
    class_values = class_values[class_order]
    class_vectors = class_vectors[:, class_order]
    feature_values = feature_values[feature_order]
    feature_vectors = feature_vectors[:, feature_order]
    spectrum = (
        ridge
        + class_values.clamp_min(0.0)[:, None]
        * feature_values.clamp_min(0.0)[None, :]
    )
    inverse_scale = spectrum.rsqrt()

    def inverse_sqrt(vector: Tensor) -> Tensor:
        matrix = vector.reshape(probabilities.shape[1], features.shape[1])
        coordinates = class_vectors.T @ matrix @ feature_vectors
        return (
            class_vectors @ (inverse_scale * coordinates) @ feature_vectors.T
        ).reshape(-1)

    class_diagonal = (
        probabilities @ class_vectors.square()
        - (probabilities @ class_vectors).square()
    )
    feature_coordinates = features @ feature_vectors
    ekfac_spectrum = (
        class_diagonal.T @ feature_coordinates.square() / len(features) + ridge
    )
    ekfac_inverse_scale = ekfac_spectrum.clamp_min(ridge).rsqrt()

    def ekfac_inverse_sqrt(vector: Tensor) -> Tensor:
        matrix = vector.reshape(probabilities.shape[1], features.shape[1])
        coordinates = class_vectors.T @ matrix @ feature_vectors
        return (
            class_vectors @ (ekfac_inverse_scale * coordinates) @ feature_vectors.T
        ).reshape(-1)

    positive_class = torch.nonzero(class_values > 1e-10, as_tuple=False)[:, 0]
    class_selected = positive_class[: probabilities.shape[1] - 1]
    feature_selected = torch.arange(min(feature_modes, features.shape[1]))
    support_columns = []
    whitened_columns = []
    for class_index in class_selected.tolist():
        for feature_index in feature_selected.tolist():
            column = torch.outer(
                class_vectors[:, class_index], feature_vectors[:, feature_index]
            ).reshape(-1)
            support_columns.append(column)
            whitened_columns.append(
                column / spectrum[class_index, feature_index].sqrt()
            )
    support = torch.stack(support_columns, dim=1)
    whitened_support = torch.stack(whitened_columns, dim=1)
    metadata = {
        "class_factor_effective_rank": int((class_values > 1e-10).sum().item()),
        "feature_factor_effective_rank": int((feature_values > 1e-10).sum().item()),
        "kfac_spectrum_min": spectrum.min().item(),
        "kfac_spectrum_max": spectrum.max().item(),
        "ekfac_spectrum_min": ekfac_spectrum.min().item(),
        "ekfac_spectrum_max": ekfac_spectrum.max().item(),
    }
    return inverse_sqrt, ekfac_inverse_sqrt, support, whitened_support, metadata


def reduced_hessian(
    features: Tensor,
    probabilities: Tensor,
    ridge: float,
    whitened_support: Tensor,
) -> Tensor:
    hessian = HeadHessian(features, probabilities, ridge)
    columns = [
        whitened_support.T @ hessian.product(whitened_support[:, column])
        for column in range(whitened_support.shape[1])
    ]
    matrix = torch.stack(columns, dim=1)
    return (matrix + matrix.T) / 2


def reduced_kfac(
    features: Tensor,
    probabilities: Tensor,
    ridge: float,
    whitened_support: Tensor,
) -> Tensor:
    class_factor = torch.diag(probabilities.mean(0)) - (
        probabilities.T @ probabilities / len(probabilities)
    )
    feature_factor = features.T @ features / len(features)

    def product(vector: Tensor) -> Tensor:
        matrix = vector.reshape(probabilities.shape[1], features.shape[1])
        return (class_factor @ matrix @ feature_factor + ridge * matrix).reshape(-1)

    columns = [
        whitened_support.T @ product(whitened_support[:, column])
        for column in range(whitened_support.shape[1])
    ]
    matrix = torch.stack(columns, dim=1)
    return (matrix + matrix.T) / 2


def historical_basis(
    features: Tensor,
    probabilities: Tensor,
    ridge: float,
    whitened_support: Tensor,
    atoms: int,
    subset_size: int,
    seed: int,
    tolerance: float = 1e-9,
) -> tuple[Tensor, dict[str, float]]:
    rng = np.random.default_rng(seed)
    matrices = []
    start = time.perf_counter()
    for _ in range(atoms):
        indices = rng.choice(len(features), size=subset_size, replace=False)
        index_tensor = torch.from_numpy(indices)
        matrix = reduced_hessian(
            features[index_tensor], probabilities[index_tensor], ridge,
            whitened_support,
        )
        baseline = reduced_kfac(
            features[index_tensor], probabilities[index_tensor], ridge,
            whitened_support,
        )
        matrices.append(matrix - baseline)
    raw = torch.stack(matrices)
    flat = raw.reshape(atoms, -1)
    _, singular, right = torch.linalg.svd(flat, full_matrices=False)
    rank = int((singular > tolerance * singular[0]).sum().item())
    dimension = whitened_support.shape[1]
    basis = right[:rank].reshape(rank, dimension, dimension)
    metadata = {
        "historical_family_rank": rank,
        "historical_family_build_seconds": time.perf_counter() - start,
        "historical_top_singular": singular[0].item(),
        "historical_bottom_retained_singular": singular[rank - 1].item(),
    }
    return basis, metadata


def pcg_iterations(
    operator,
    preconditioner,
    dimension: int,
    right_hand_sides: int,
    tolerance: float,
    maximum_iterations: int,
    seed: int,
) -> list[int]:
    generator = torch.Generator().manual_seed(seed)
    counts = []
    for _ in range(right_hand_sides):
        right = torch.randn(dimension, generator=generator)
        solution = torch.zeros_like(right)
        residual = right.clone()
        initial_norm = residual.norm().item()
        preconditioned = preconditioner(residual)
        direction = preconditioned.clone()
        inner = torch.dot(residual, preconditioned)
        completed = maximum_iterations
        for iteration in range(1, maximum_iterations + 1):
            product = operator(direction)
            denominator = torch.dot(direction, product)
            if denominator <= 0:
                break
            step = inner / denominator
            solution += step * direction
            residual -= step * product
            if residual.norm().item() <= tolerance * initial_norm:
                completed = iteration
                break
            next_preconditioned = preconditioner(residual)
            next_inner = torch.dot(residual, next_preconditioned)
            direction = next_preconditioned + (next_inner / inner) * direction
            preconditioned = next_preconditioned
            inner = next_inner
        counts.append(completed)
    return counts


def run(arguments: argparse.Namespace) -> dict:
    seed_everything(arguments.seed)
    root = Path(__file__).resolve().parent
    os.environ.setdefault("TORCH_HOME", str(root / "torch_cache"))
    total_curvature = arguments.reference_count + arguments.target_count
    required_train = max(arguments.train_count, total_curvature)
    cache = root / (
        f"v3_features_train{required_train}_test{arguments.test_count}_"
        f"seed{arguments.data_seed}.pt"
    )
    train_x, train_y, test_x, test_y, feature_meta = extract_features(
        root / "data", cache, required_train, arguments.test_count,
        arguments.data_seed,
    )
    train_x, train_y = train_x.clone(), train_y.clone()
    test_x, test_y = test_x.clone(), test_y.clone()
    torch.set_default_dtype(torch.float64)
    train_x, test_x = standardize_and_append_bias(train_x, test_x)
    head, fit_meta = fit_head(train_x, train_y, 10, arguments.ridge)
    with torch.no_grad():
        probabilities = (train_x @ head.T).softmax(1)
        test_accuracy = (
            (test_x @ head.T).argmax(1).eq(test_y).double().mean().item()
        )

    reference_x = train_x[: arguments.reference_count]
    reference_p = probabilities[: arguments.reference_count]
    target_start = arguments.reference_count
    target_stop = target_start + arguments.target_count
    target_x = train_x[target_start:target_stop]
    target_p = probabilities[target_start:target_stop]
    target_hessian = HeadHessian(target_x, target_p, arguments.ridge)
    kfac_whiten, ekfac_whiten, support, whitened_support, kfac_meta = kfac_geometry(
        target_x, target_p, arguments.ridge, arguments.feature_modes
    )

    def whitened_target(vector: Tensor) -> Tensor:
        inner = kfac_whiten(vector)
        return kfac_whiten(target_hessian.product(inner))

    def target_residual(vector: Tensor) -> Tensor:
        return whitened_target(vector) - vector

    basis, family_meta = historical_basis(
        reference_x, reference_p, arguments.ridge, whitened_support,
        arguments.dictionary, arguments.subset_size, arguments.seed + 1,
    )
    family_dimension, reduced_dimension, _ = basis.shape
    profile_start = time.perf_counter()
    eigenvalues, eigenvectors, profiles = residual_profiles(
        basis, max(arguments.budgets)
    )
    exact_ranks = [
        choose_exact_rank(
            budget, profiles, reduced_dimension, family_dimension
        )
        for budget in arguments.budgets
    ]
    profile_seconds = time.perf_counter() - profile_start

    evaluation_start = time.perf_counter()
    target_reduced = reduced_hessian(
        target_x, target_p, arguments.ridge, whitened_support
    ) - torch.eye(reduced_dimension)
    evaluation_reduced_seconds = time.perf_counter() - evaluation_start
    coefficients = torch.einsum("iab,ab->i", basis, target_reduced)
    oracle_correction = matrix_from_coefficients(coefficients, basis)
    projection_energy = coefficients.square().sum().item()
    residual_norm, residual_se, norm_seconds = randomized_frobenius_squared(
        target_residual, target_hessian.dimension, arguments.norm_probes,
        arguments.seed + 17,
    )
    optimum_error = residual_norm - projection_energy

    query_results = {}
    selected_candidates = {"gaussian": [], "spectral_fibers": []}
    for budget, exact_rank in zip(arguments.budgets, exact_ranks):
        gaussian_ratios, fiber_ratios = [], []
        gaussian_excess, fiber_excess = [], []
        for trial in range(arguments.trials):
            trial_seed = arguments.seed * 100000 + budget * 100 + trial
            generator = torch.Generator().manual_seed(trial_seed)
            gaussian = gaussian_regression(
                target_reduced, basis, budget, generator
            )
            generator = torch.Generator().manual_seed(trial_seed)
            fiber = symmetric_fiber_regression(
                target_reduced, basis, eigenvectors, budget, exact_rank,
                generator,
            )
            gaussian_ratios.append(
                full_error(residual_norm, target_reduced, gaussian) / optimum_error
            )
            fiber_ratios.append(
                full_error(residual_norm, target_reduced, fiber) / optimum_error
            )
            gaussian_excess.append(
                (gaussian - oracle_correction).square().sum().item()
                / max(projection_energy, 1e-30)
            )
            fiber_excess.append(
                (fiber - oracle_correction).square().sum().item()
                / max(projection_energy, 1e-30)
            )
            if budget == arguments.precondition_budget:
                selected_candidates["gaussian"].append(
                    (gaussian_excess[-1], trial, gaussian)
                )
                selected_candidates["spectral_fibers"].append(
                    (fiber_excess[-1], trial, fiber)
                )
        query_results[str(budget)] = {
            "exact_rank": exact_rank,
            "gaussian_relative_error_median": float(np.median(gaussian_ratios)),
            "fiber_relative_error_median": float(np.median(fiber_ratios)),
            "gaussian_projection_excess_median": float(np.median(gaussian_excess)),
            "fiber_projection_excess_median": float(np.median(fiber_excess)),
            "gaussian_projection_excess_p90": float(np.quantile(gaussian_excess, 0.9)),
            "fiber_projection_excess_p90": float(np.quantile(fiber_excess, 0.9)),
        }

    selected_estimates = {}
    selected_trials = {}
    for name, candidates in selected_candidates.items():
        if not candidates:
            raise ValueError("precondition budget must be included in budgets")
        ordered = sorted(candidates, key=lambda item: item[0])
        _, trial, estimate = ordered[len(ordered) // 2]
        selected_estimates[name] = estimate
        selected_trials[name] = trial

    condition_results = {}
    corrections = {"family_oracle": oracle_correction, **selected_estimates}
    for name, correction in corrections.items():
        correction_whiten, minimum, clipped = identity_plus_low_rank_inverse_sqrt(
            support, correction, arguments.eigenvalue_floor
        )

        def transformed(vector: Tensor) -> Tensor:
            inner = correction_whiten(vector)
            return correction_whiten(whitened_target(inner))

        smallest, largest, condition = lanczos_condition(
            transformed, target_hessian.dimension, arguments.lanczos_steps,
            arguments.seed + 200,
        )
        def actual_inverse(vector: Tensor) -> Tensor:
            inner = kfac_whiten(vector)
            inner = correction_whiten(correction_whiten(inner))
            return kfac_whiten(inner)

        pcg_counts = pcg_iterations(
            target_hessian.product, actual_inverse, target_hessian.dimension,
            arguments.pcg_right_hand_sides, arguments.pcg_tolerance,
            arguments.pcg_max_iterations, arguments.seed + 300,
        )
        condition_results[name] = {
            "ritz_min": smallest,
            "ritz_max": largest,
            "ritz_condition": condition,
            "minimum_preclip_eigenvalue": minimum,
            "clipped_eigenvalues": clipped,
            "pcg_iterations_median": float(np.median(pcg_counts)),
            "pcg_iterations_p90": float(np.quantile(pcg_counts, 0.9)),
            "pcg_converged_fraction": float(np.mean(
                np.asarray(pcg_counts) < arguments.pcg_max_iterations
            )),
        }
    kfac_min, kfac_max, kfac_condition = lanczos_condition(
        whitened_target, target_hessian.dimension, arguments.lanczos_steps,
        arguments.seed + 200,
    )
    def kfac_inverse(vector: Tensor) -> Tensor:
        return kfac_whiten(kfac_whiten(vector))

    kfac_pcg = pcg_iterations(
        target_hessian.product, kfac_inverse, target_hessian.dimension,
        arguments.pcg_right_hand_sides, arguments.pcg_tolerance,
        arguments.pcg_max_iterations, arguments.seed + 300,
    )
    condition_results["target_kfac"] = {
        "ritz_min": kfac_min,
        "ritz_max": kfac_max,
        "ritz_condition": kfac_condition,
        "pcg_iterations_median": float(np.median(kfac_pcg)),
        "pcg_iterations_p90": float(np.quantile(kfac_pcg, 0.9)),
        "pcg_converged_fraction": float(np.mean(
            np.asarray(kfac_pcg) < arguments.pcg_max_iterations
        )),
    }

    def whitened_ekfac_target(vector: Tensor) -> Tensor:
        inner = ekfac_whiten(vector)
        return ekfac_whiten(target_hessian.product(inner))

    ekfac_min, ekfac_max, ekfac_condition = lanczos_condition(
        whitened_ekfac_target, target_hessian.dimension,
        arguments.lanczos_steps, arguments.seed + 200,
    )

    def ekfac_inverse(vector: Tensor) -> Tensor:
        return ekfac_whiten(ekfac_whiten(vector))

    ekfac_pcg = pcg_iterations(
        target_hessian.product, ekfac_inverse, target_hessian.dimension,
        arguments.pcg_right_hand_sides, arguments.pcg_tolerance,
        arguments.pcg_max_iterations, arguments.seed + 300,
    )
    condition_results["target_ekfac"] = {
        "ritz_min": ekfac_min,
        "ritz_max": ekfac_max,
        "ritz_condition": ekfac_condition,
        "pcg_iterations_median": float(np.median(ekfac_pcg)),
        "pcg_iterations_p90": float(np.quantile(ekfac_pcg, 0.9)),
        "pcg_converged_fraction": float(np.mean(
            np.asarray(ekfac_pcg) < arguments.pcg_max_iterations
        )),
    }

    target_diagonal = arguments.ridge + torch.einsum(
        "nc,nf->ncf", target_p * (1.0 - target_p), target_x.square()
    ).mean(0).reshape(-1)

    def jacobi_target(vector: Tensor) -> Tensor:
        inner = vector / target_diagonal.sqrt()
        return target_hessian.product(inner) / target_diagonal.sqrt()

    jacobi_min, jacobi_max, jacobi_condition = lanczos_condition(
        jacobi_target, target_hessian.dimension, arguments.lanczos_steps,
        arguments.seed + 200,
    )
    none_min, none_max, none_condition = lanczos_condition(
        target_hessian.product, target_hessian.dimension,
        arguments.lanczos_steps, arguments.seed + 200,
    )
    jacobi_pcg = pcg_iterations(
        target_hessian.product, lambda vector: vector / target_diagonal,
        target_hessian.dimension, arguments.pcg_right_hand_sides,
        arguments.pcg_tolerance, arguments.pcg_max_iterations,
        arguments.seed + 300,
    )
    none_pcg = pcg_iterations(
        target_hessian.product, lambda vector: vector,
        target_hessian.dimension, arguments.pcg_right_hand_sides,
        arguments.pcg_tolerance, arguments.pcg_max_iterations,
        arguments.seed + 300,
    )
    condition_results["target_jacobi"] = {
        "ritz_min": jacobi_min,
        "ritz_max": jacobi_max,
        "ritz_condition": jacobi_condition,
        "pcg_iterations_median": float(np.median(jacobi_pcg)),
        "pcg_iterations_p90": float(np.quantile(jacobi_pcg, 0.9)),
        "pcg_converged_fraction": float(np.mean(
            np.asarray(jacobi_pcg) < arguments.pcg_max_iterations
        )),
    }
    condition_results["none"] = {
        "ritz_min": none_min,
        "ritz_max": none_max,
        "ritz_condition": none_condition,
        "pcg_iterations_median": float(np.median(none_pcg)),
        "pcg_iterations_p90": float(np.quantile(none_pcg, 0.9)),
        "pcg_converged_fraction": float(np.mean(
            np.asarray(none_pcg) < arguments.pcg_max_iterations
        )),
    }

    result = {
        "seed": arguments.seed,
        "data_seed": arguments.data_seed,
        "model": "ImageNet-pretrained MobileNetV3-Small frozen backbone",
        "dataset": "CIFAR-10",
        "train_examples": len(train_x),
        "test_examples": len(test_x),
        "reference_examples": len(reference_x),
        "target_examples": len(target_x),
        "hessian_dimension": target_hessian.dimension,
        "feature_modes": arguments.feature_modes,
        "reduced_dimension": reduced_dimension,
        "dictionary_atoms": arguments.dictionary,
        "subset_size": arguments.subset_size,
        "family_dimension": family_dimension,
        "test_accuracy": test_accuracy,
        "ridge": arguments.ridge,
        "residual_frobenius_squared_estimate": residual_norm,
        "residual_frobenius_standard_error": residual_se,
        "family_projection_energy": projection_energy,
        "family_optimum_error_estimate": optimum_error,
        "family_explained_residual_fraction": projection_energy / residual_norm,
        "partial_trace_top10": eigenvalues[:10].tolist(),
        "query_results": query_results,
        "condition_results": condition_results,
        "precondition_budget": arguments.precondition_budget,
        "representative_precondition_trials": selected_trials,
        "estimator_trials": arguments.trials,
        "pcg_right_hand_sides": arguments.pcg_right_hand_sides,
        "pcg_tolerance": arguments.pcg_tolerance,
        "pcg_max_iterations": arguments.pcg_max_iterations,
        "norm_probes": arguments.norm_probes,
        "evaluation_only_hvps": reduced_dimension + arguments.norm_probes,
        "evaluation_reduced_matrix_seconds": evaluation_reduced_seconds,
        "evaluation_norm_seconds": norm_seconds,
        "profile_seconds": profile_seconds,
        **kfac_meta,
        **family_meta,
        **feature_meta,
        **fit_meta,
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return result


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--train-count", type=int, default=4000)
    parser.add_argument("--test-count", type=int, default=1000)
    parser.add_argument("--reference-count", type=int, default=1000)
    parser.add_argument("--target-count", type=int, default=1000)
    parser.add_argument("--feature-modes", type=int, default=16)
    parser.add_argument("--dictionary", type=int, default=64)
    parser.add_argument("--subset-size", type=int, default=250)
    parser.add_argument("--budgets", type=int, nargs="+", default=[8, 12, 16, 24, 32, 48])
    parser.add_argument("--trials", type=int, default=30)
    parser.add_argument("--precondition-budget", type=int, default=24)
    parser.add_argument("--lanczos-steps", type=int, default=40)
    parser.add_argument("--norm-probes", type=int, default=256)
    parser.add_argument("--pcg-right-hand-sides", type=int, default=10)
    parser.add_argument("--pcg-tolerance", type=float, default=1e-6)
    parser.add_argument("--pcg-max-iterations", type=int, default=300)
    parser.add_argument("--ridge", type=float, default=1e-3)
    parser.add_argument("--eigenvalue-floor", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=2027)
    parser.add_argument("--data-seed", type=int, default=2027)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().parent / "historical_curvature_results.json",
    )
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_arguments())
