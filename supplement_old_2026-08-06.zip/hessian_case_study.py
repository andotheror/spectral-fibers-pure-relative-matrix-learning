"""Reproduce the real-data Hessian experiment in FiberRegression_v2.

The experiment uses the built-in scikit-learn digits data.  It fits a binary
logistic model, forms its exact Hessian only for evaluation, and exposes the
Hessian to both estimators through products.  The approximation family is a
known dense curvature dictionary spanned by the identity and normalized
sample outer products.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import scipy.linalg as sla
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


def problem(seed: int = 7):
    rng = np.random.default_rng(seed)
    features, labels = load_digits(return_X_y=True)
    labels = (labels >= 5).astype(int)
    keep = features.std(axis=0) > 1e-8
    features = StandardScaler().fit_transform(features[:, keep])
    n, dimension = features.shape

    model = LogisticRegression(
        C=10.0, fit_intercept=False, max_iter=500, solver="liblinear"
    ).fit(features, labels)
    probability = model.predict_proba(features)[:, 1]
    weights = probability * (1.0 - probability)
    ridge = 1e-2
    hessian = (features.T * weights) @ features / n + ridge * np.eye(dimension)

    chosen = rng.choice(n, size=63, replace=False)
    atoms = [np.eye(dimension) / np.sqrt(dimension)]
    for index in chosen:
        vector = features[index]
        atoms.append(np.outer(vector, vector) / np.linalg.norm(vector) ** 2)
    atom_matrix = np.stack([atom.ravel() for atom in atoms], axis=1)
    orthogonal, triangular = np.linalg.qr(atom_matrix, mode="reduced")
    rank = int(np.sum(np.abs(np.diag(triangular)) > 1e-10))
    basis = orthogonal[:, :rank].T.reshape(rank, dimension, dimension)
    return features, labels, hessian, basis, ridge


def residual_profiles(basis: np.ndarray, max_rank: int):
    q, dimension, _ = basis.shape
    partial_trace = np.einsum("iab,icb->ac", basis, basis, optimize=True)
    eigenvalues, eigenvectors = np.linalg.eigh(partial_trace)
    order = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[order]
    eigenvectors = eigenvectors[:, order]
    profiles = []
    identity = np.eye(dimension)
    for rank in range(max_rank + 1):
        high = eigenvectors[:, :rank]
        complement = identity - high @ high.T
        residual = np.einsum(
            "ab,ibc,cd->iad", complement, basis, complement, optimize=True
        )
        gamma_matrix = np.einsum(
            "iab,icb->ac", residual, residual, optimize=True
        )
        gamma = float(np.linalg.eigvalsh(gamma_matrix)[-1])
        beta = float(
            np.linalg.svd(residual.reshape(q, -1), compute_uv=False)[0] ** 2
        )
        profiles.append((gamma, beta))
    return eigenvalues, eigenvectors, profiles


def choose_exact_rank(
    budget: int, profiles: list[tuple[float, float]], dimension: int, q: int
) -> int:
    """Choose exact fibers from the theorem's family-only concentration proxy."""
    scores = []
    for rank in range(budget):
        gamma, beta = profiles[rank]
        sigma2 = max(gamma, beta)
        logs = np.log(2 * q) * np.log(
            2 * (dimension + q) * (1 + sigma2) * np.log(2 * q)
        )
        scores.append(((gamma + sigma2 * logs) / (budget - rank), rank))
    return min(scores)[1]


def matrix_from_coefficients(coefficients: np.ndarray, basis: np.ndarray):
    return np.einsum("i,iab->ab", coefficients, basis, optimize=True)


def gaussian_regression(
    hessian: np.ndarray, basis: np.ndarray, budget: int, rng: np.random.Generator
):
    q, dimension, _ = basis.shape
    probes = rng.standard_normal((dimension, budget))
    design = np.stack(
        [
            np.stack([matrix @ probes[:, j] for matrix in basis], axis=1)
            for j in range(budget)
        ],
        axis=0,
    )
    response = hessian @ probes
    coefficients = np.linalg.lstsq(
        design.reshape(budget * dimension, q),
        response.T.reshape(budget * dimension),
        rcond=None,
    )[0]
    return matrix_from_coefficients(coefficients, basis)


def symmetric_fiber_regression(
    hessian: np.ndarray,
    basis: np.ndarray,
    eigenvectors: np.ndarray,
    budget: int,
    exact_rank: int,
    rng: np.random.Generator,
):
    q, dimension, _ = basis.shape
    high = eigenvectors[:, :exact_rank]
    complement = np.eye(dimension) - high @ high.T
    designs = []
    responses = []

    if exact_rank:
        left_design = np.stack([high.T @ matrix for matrix in basis], axis=-1)
        cross_design = np.stack(
            [complement @ matrix @ high for matrix in basis], axis=-1
        )
        designs.extend(
            [
                left_design.reshape(exact_rank * dimension, q),
                cross_design.reshape(dimension * exact_rank, q),
            ]
        )
        responses.extend(
            [
                (high.T @ hessian).reshape(exact_rank * dimension),
                (complement @ hessian @ high).reshape(dimension * exact_rank),
            ]
        )

    random_count = budget - exact_rank
    probes = complement @ rng.standard_normal((dimension, random_count))
    random_design = np.stack(
        [
            np.stack(
                [complement @ matrix @ probes[:, j] for matrix in basis], axis=1
            )
            for j in range(random_count)
        ],
        axis=0,
    )
    scale = 1.0 / np.sqrt(random_count)
    designs.append(scale * random_design.reshape(random_count * dimension, q))
    responses.append(
        scale * (complement @ hessian @ probes).T.reshape(random_count * dimension)
    )

    coefficients = np.linalg.lstsq(
        np.concatenate(designs, axis=0), np.concatenate(responses), rcond=None
    )[0]
    return matrix_from_coefficients(coefficients, basis)


def psd_clip(matrix: np.ndarray, floor: float):
    eigenvalues, eigenvectors = sla.eigh((matrix + matrix.T) / 2)
    return (eigenvectors * np.maximum(eigenvalues, floor)) @ eigenvectors.T


def preconditioned_condition(hessian: np.ndarray, estimate: np.ndarray, floor: float):
    eigenvalues = sla.eigvalsh(hessian, psd_clip(estimate, floor))
    return float(eigenvalues[-1] / eigenvalues[0])


def run(trials: int, output: Path, seed: int = 7):
    features, labels, hessian, basis, ridge = problem(seed)
    q, dimension, _ = basis.shape
    budgets = np.array([4, 6, 8, 12, 16, 24, 32, 40])
    eigenvalues, eigenvectors, profiles = residual_profiles(
        basis, int(budgets.max())
    )
    exact_ranks = np.array(
        [choose_exact_rank(int(budget), profiles, dimension, q) for budget in budgets]
    )

    coefficients = np.einsum("iab,ab->i", basis, hessian, optimize=True)
    optimum_matrix = matrix_from_coefficients(coefficients, basis)
    optimum_error = np.linalg.norm(hessian - optimum_matrix, "fro") ** 2

    gaussian_errors = np.empty((len(budgets), trials))
    fiber_errors = np.empty_like(gaussian_errors)
    gaussian_conditions = np.empty_like(gaussian_errors)
    fiber_conditions = np.empty_like(gaussian_errors)
    for row, (budget, exact_rank) in enumerate(zip(budgets, exact_ranks)):
        for trial in range(trials):
            trial_seed = 10_000 + 100 * int(budget) + trial
            gaussian = gaussian_regression(
                hessian, basis, int(budget), np.random.default_rng(trial_seed)
            )
            fiber = symmetric_fiber_regression(
                hessian,
                basis,
                eigenvectors,
                int(budget),
                int(exact_rank),
                np.random.default_rng(trial_seed),
            )
            gaussian_errors[row, trial] = (
                np.linalg.norm(hessian - gaussian, "fro") ** 2 / optimum_error
            )
            fiber_errors[row, trial] = (
                np.linalg.norm(hessian - fiber, "fro") ** 2 / optimum_error
            )
            gaussian_conditions[row, trial] = preconditioned_condition(
                hessian, gaussian, ridge
            )
            fiber_conditions[row, trial] = preconditioned_condition(
                hessian, fiber, ridge
            )

    jacobi_condition = preconditioned_condition(
        hessian, np.diag(np.diag(hessian)), ridge
    )
    oracle_condition = preconditioned_condition(hessian, optimum_matrix, ridge)
    unpreconditioned = float(np.linalg.cond(hessian))

    colors = {"fiber": "#0b6e99", "gaussian": "#c95024"}
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.15))
    for values, label, color in [
        (fiber_errors, "spectral fibers", colors["fiber"]),
        (gaussian_errors, "Gaussian regression", colors["gaussian"]),
    ]:
        median = np.median(values, axis=1)
        low, high = np.quantile(values, [0.1, 0.9], axis=1)
        axes[0].plot(budgets, median, marker="o", label=label, color=color)
        axes[0].fill_between(budgets, low, high, alpha=0.16, color=color)
    axes[0].axhline(1.1, color="0.35", linestyle="--", linewidth=1, label="1.1 target")
    axes[0].set_xlabel("Hessian-vector products")
    axes[0].set_ylabel(
        r"$\|H-\widehat B\|_F^2/\min_{B\in\mathcal{L}}\|H-B\|_F^2$"
    )
    axes[0].set_yscale("log")
    axes[0].set_ylim(0.98, 4.3)
    axes[0].set_title("(a) Pure relative error")
    axes[0].grid(alpha=0.22)
    axes[0].legend(frameon=False, fontsize=8)

    for values, label, color in [
        (fiber_conditions, "spectral fibers", colors["fiber"]),
        (gaussian_conditions, "Gaussian regression", colors["gaussian"]),
    ]:
        median = np.median(values, axis=1)
        low, high = np.quantile(values, [0.1, 0.9], axis=1)
        axes[1].plot(budgets, median, marker="o", label=label, color=color)
        axes[1].fill_between(budgets, low, high, alpha=0.16, color=color)
    axes[1].axhline(
        oracle_condition, color="#4b8b3b", linestyle="--", linewidth=1, label="family oracle"
    )
    axes[1].axhline(
        jacobi_condition, color="0.4", linestyle=":", linewidth=1, label="Jacobi"
    )
    axes[1].set_xlabel("Hessian-vector products")
    axes[1].set_ylabel("PSD-clipped preconditioned condition number")
    axes[1].set_title("(b) Downstream conditioning")
    axes[1].grid(alpha=0.22)
    axes[1].legend(frameon=False, fontsize=8)
    fig.tight_layout(pad=0.8)
    fig.savefig(output, bbox_inches="tight")

    summary_path = output.with_name("hessian_case_study_output.txt")
    lines = [
        f"samples={features.shape[0]} dimension={dimension} family_dimension={q}",
        f"class_balance={labels.mean():.10f}",
        f"optimum_error_fraction={optimum_error / np.linalg.norm(hessian, 'fro') ** 2:.10f}",
        f"partial_trace_top8={np.array2string(eigenvalues[:8], precision=6)}",
        f"unpreconditioned_condition={unpreconditioned:.10f}",
        f"jacobi_condition={jacobi_condition:.10f}",
        f"family_oracle_condition={oracle_condition:.10f}",
    ]
    for row, (budget, exact_rank) in enumerate(zip(budgets, exact_ranks)):
        lines.append(
            "budget={} exact_rank={} gaussian_error_median={:.10f} "
            "fiber_error_median={:.10f} gaussian_condition_median={:.10f} "
            "fiber_condition_median={:.10f}".format(
                budget,
                exact_rank,
                np.median(gaussian_errors[row]),
                np.median(fiber_errors[row]),
                np.median(gaussian_conditions[row]),
                np.median(fiber_conditions[row]),
            )
        )
    summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=80)
    parser.add_argument("--output", type=Path, default=Path("hessian_case_study.pdf"))
    parser.add_argument("--seed", type=int, default=7)
    arguments = parser.parse_args()
    run(arguments.trials, arguments.output, arguments.seed)
