"""Mechanism check for spectral fiber regression on coordinate families."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def make_supports(kind: str, n: int, rng: np.random.Generator) -> list[np.ndarray]:
    if kind == "regular":
        degrees = np.full(n, 2, dtype=int)
    elif kind == "heterogeneous":
        degrees = np.zeros(n, dtype=int)
        degrees[:6] = 36
        degrees[6:114] = 1
    else:
        raise ValueError(kind)
    return [rng.choice(n, size=d, replace=False) for d in degrees]


def choose_high_rows(supports: list[np.ndarray], budget: int) -> np.ndarray:
    """Minimize a family-only worst-row Gaussian-regression variance proxy."""
    degrees = np.asarray([len(s) for s in supports])
    best_score = np.inf
    best_high = np.zeros(len(supports), dtype=bool)
    for cutoff in np.unique(np.concatenate(([-1], degrees))):
        high = degrees > cutoff
        right_queries = budget - int(high.sum())
        if right_queries <= 0:
            continue
        low_degrees = degrees[~high]
        max_low = int(low_degrees.max()) if low_degrees.size else 0
        if max_low == 0:
            score = 0.0
        elif right_queries <= max_low + 1:
            score = np.inf
        else:
            score = max_low / (right_queries - max_low - 1)
        if score < best_score:
            best_score = score
            best_high = high
    return best_high


def target_and_residual(
    supports: list[np.ndarray], rng: np.random.Generator
) -> tuple[np.ndarray, np.ndarray]:
    n = len(supports)
    target = rng.normal(size=(n, n))
    mask = np.zeros((n, n), dtype=bool)
    for i, support in enumerate(supports):
        mask[i, support] = True
    residual = target.copy()
    residual[mask] = 0.0
    residual /= np.linalg.norm(residual)
    signal = np.zeros_like(target)
    signal[mask] = rng.normal(size=int(mask.sum()))
    return signal + residual, residual


def fit_rows(
    target: np.ndarray,
    supports: list[np.ndarray],
    probes: np.ndarray,
    high: np.ndarray,
) -> np.ndarray:
    fitted = np.zeros_like(target)
    responses = target @ probes if probes.shape[1] else np.zeros((len(target), 0))
    for i, support in enumerate(supports):
        if support.size == 0:
            continue
        if high[i]:
            fitted[i, support] = target[i, support]
            continue
        design = probes[support, :].T
        coefficients, *_ = np.linalg.lstsq(design, responses[i], rcond=None)
        fitted[i, support] = coefficients
    return fitted


def run(kind: str, seed: int = 0) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = 180
    budgets = np.arange(8, 73, 4)
    trials = 80
    rng = np.random.default_rng(seed)
    supports = make_supports(kind, n, rng)
    hybrid = np.empty((trials, len(budgets)))
    one_sided = np.empty_like(hybrid)
    for trial in range(trials):
        target, residual = target_and_residual(supports, rng)
        optimum = np.linalg.norm(residual)
        all_probes = rng.normal(size=(n, int(budgets.max())))
        for j, budget in enumerate(budgets):
            high = choose_high_rows(supports, int(budget))
            right = int(budget - high.sum())
            hybrid_fit = fit_rows(target, supports, all_probes[:, :right], high)
            baseline_fit = fit_rows(
                target,
                supports,
                all_probes[:, : int(budget)],
                np.zeros(n, dtype=bool),
            )
            hybrid[trial, j] = np.linalg.norm(target - hybrid_fit) / optimum
            one_sided[trial, j] = np.linalg.norm(target - baseline_fit) / optimum
    return budgets, hybrid, one_sided


def summarize(values: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    return (
        np.median(values, axis=0),
        np.quantile(values, 0.1, axis=0),
        np.quantile(values, 0.9, axis=0),
    )


def main() -> None:
    plt.rcParams.update(
        {
            "font.size": 9,
            "axes.labelsize": 9,
            "axes.titlesize": 10,
            "legend.fontsize": 8,
            "pdf.fonttype": 42,
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(6.7, 2.35), sharey=True)
    for axis, kind, seed, title in zip(
        axes,
        ["regular", "heterogeneous"],
        [41, 73],
        ["Regular row leverage", "Six dense exceptional rows"],
    ):
        budgets, hybrid, baseline = run(kind, seed)
        for values, color, marker, label in [
            (hybrid, "#1764ab", "o", "spectral fiber regression"),
            (baseline, "#c53b2c", "s", "one-sided Gaussian regression"),
        ]:
            median, low, high = summarize(values)
            axis.plot(
                budgets,
                median,
                color=color,
                marker=marker,
                markersize=3,
                linewidth=1.4,
                label=label,
            )
            axis.fill_between(budgets, low, high, color=color, alpha=0.15, linewidth=0)
        axis.axhline(1.0, color="black", linewidth=0.8, linestyle="--")
        axis.set_title(title)
        axis.set_xlabel("total matrix-vector products")
        axis.grid(alpha=0.2, linewidth=0.5)
        axis.set_yscale("log")
    axes[0].set_ylabel(r"$\|A-\widehat B\|_F/\mathrm{OPT}$")
    axes[0].legend(loc="upper right", frameon=False)
    fig.tight_layout(pad=0.6, w_pad=0.9)
    output = Path(__file__).with_name("fiber_tradeoff.pdf")
    fig.savefig(output, bbox_inches="tight")
    print(output)


if __name__ == "__main__":
    main()
